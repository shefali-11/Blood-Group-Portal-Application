<?php
include "header.php";
include "db_conf.php";

$bcdt=$_POST["bcdt"];
$arrb=$_POST["arrb"];
$cp=$_POST["cp"];
$ci=$_POST["ci"];
$loc=$_POST["loc"];
$tal=$_POST["tal"];
$adr=$_POST["adr"];



$query="insert into blood_camp(bcdt,arranged_by,contact_person,con_info,loc,taluka,address) values('$bcdt','$arrb','$cp','$ci','$loc','$tal','$adr')";

	mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."<a href='new_blood_camp.php'>Try Again</a></h3>");

	if(mysqli_affected_rows($con) > 0)
	{
		
		echo "<div class='alert alert-success text-center' style='margin-top:15px'><h3>SUCCESS: New Blood Camp Added</h3>";
		echo "<p><a href='a_blood_camp_list.php'>Back To List</a></p></div>";
	}
	else
	{
		echo "<div class='alert alert-danger text-center'  style='margin-top:15px'><h3>ERROR: Cannot Add Blood Camp. <a href='new_blood_camp.php'>Try Again</a></h3></div>";
	}


include "footer.php";
?>