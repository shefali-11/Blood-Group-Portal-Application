<?php
include "header.php";

$fn=$_POST["fn"];
$loc=$_POST["loc"];
$ci=$_POST["ci"];
$bg=$_POST["bg"];
$ge=$_POST["ge"];
$age=$_POST["age"];
$tal=$_POST["tal"];
$adr=$_POST["adr"];

	include "db_conf.php";

	$query="update profile set fullname='$fn', location='$loc', con_info='$ci', address='$adr' , taluka='$tal' , bgroup='$bg' , age='$age' , gender='$ge' where uname='$log_user'";

	mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."<a href='profile.php?'>Try Again</a></h3>");

	if(mysqli_affected_rows($con) > 0)
	{
		echo "<div class='alert alert-success text-center' style='margin-top:15px'><h3>SUCCESS: Profile Updated</h3>";
		echo "<p><a href='member.php'>Back To Panel</a></p></div>";
	}
	else
	{
		echo "<div class='alert alert-danger text-center'  style='margin-top:15px'><h3>Oops! Nothing To Update. <a href='member.php'>Back to Panel</a></h3></div>";
	}

include "footer.php";
?>