<?php
include "header.php";
$uname=$_POST["uname"];
$npwd=$_POST["npwd"];
$cpwd=$_POST["cpwd"];
$role="Member";

if($npwd!=$cpwd)
{
	echo "<div class='alert alert-danger text-center'  style='margin-top:15px'><h3>Error: Passwords Mismatch! <a href='register.php?t=$role'>Try Again</a></h3></div>";
}
else
{
	include "db_conf.php";

	$query="insert into login(uname,pwd,role) values('$uname','$cpwd','$role')";

	mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."<a href='register.php?t=$role'>Try Again</a></h3>");

	if(mysqli_affected_rows($con) > 0)
	{
		
		$query="insert into profile(uname) values('$uname')";
		

		mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."<a href='register.php'>Try Again</a></h3>");

		echo "<div class='alert alert-success text-center' style='margin-top:15px'><h3>SUCCESS: $uname Registered As $role</h3>";
		echo "<p>To Login <a href='index.php'>Click Here</a></p></div>";
	}
	else
	{
		echo "<div class='alert alert-danger text-center'  style='margin-top:15px'><h3>ERROR: Cannot Register $uname as $role <a href='register.php'>Try Again</a></h3></div>";
	}
}

include "footer.php";
?>