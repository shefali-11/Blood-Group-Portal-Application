<?php
include "header.php";
?>
<h2>About us</h2>
<?php
include "footer.php";
?>