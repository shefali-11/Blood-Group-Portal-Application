<?php
include "header.php";
include "db_conf.php";

$bg_dt=$_POST["bg_dt"];
$bgroup=$_POST["bgroup"];
$bg_person=$_POST["bg_person"];
$bg_con=$_POST["bg_con"];
$bg_loc=$_POST["bg_loc"];


$query="insert into request(uname,bg_dt,bgroup,bg_person,bg_con,bg_loc) values('$log_user','$bg_dt','$bgroup','$bg_person','$bg_con','$bg_loc')";

	mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."<a href='m_add_request.php'>Try Again</a></h3>");

	if(mysqli_affected_rows($con) > 0)
	{
		
		echo "<div class='alert alert-success text-center' style='margin-top:15px'><h3>SUCCESS: New Blood Request Added</h3>";
		echo "<p><a href='member.php'>Back To Panel</a></p></div>";
	}
	else
	{
		echo "<div class='alert alert-danger text-center'  style='margin-top:15px'><h3>ERROR: Cannot Add Blood Request. <a href='m_add_request.php'>Try Again</a></h3></div>";
	}


include "footer.php";
?>