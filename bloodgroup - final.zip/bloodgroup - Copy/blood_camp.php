<?php
include "header.php";
$place=isset($_POST["place"])?$_POST["place"]:"";
?>

<div class="well well-sm text-center">
<span class="badge" style="font-size:20px; margin-bottom:10px">Blood Camp List</span> 
<form class="form-inline" action="blood_camp.php" method="post">
	<div class="form-group">
	<label for="plField">&nbsp;Place</label>
	<input type="text" class="form-control" id="plField" name="place" value="<?php echo $place; ?>" placeholder="Any Location or Taluka" />
	</div>

<button type="submit" class="btn btn-primary">Search</button>
</form>

</div>

<?php
include "db_conf.php";

$query="select * from blood_camp where loc like '%$place%' or taluka like '%$place%' order by bcdt desc";

$result= mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."</h3>");
echo "<div class='table-responsive'>";
echo "<table class='table table-hover table-bordered table-striped'>";
echo "<tr><th>SrNo</th><th>Blood Camp Date</th><th>Arranged By</th><th>Contact Person</th><th>Contact Info</th><th>Location</th><th>Taluka</th><th>Address</th></tr>";

$srno=0;

while($row=mysqli_fetch_array($result))
{
	$srno++;
	$cid=$row["bcid"];
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row["bcdt"]."</td>";
              echo "<td>".$row["arranged_by"]."</td>";
              echo "<td>".$row["contact_person"]."</td>";
	echo "<td>".$row["con_info"]."</td>";
	echo "<td>".$row["loc"]."</td>";
	echo "<td>".$row["taluka"]."</td>";
	echo "<td>".$row["address"]."</td>";
	
	echo "</tr>";
}


echo "</table>";
echo "</div>";

include "footer.php";
?>