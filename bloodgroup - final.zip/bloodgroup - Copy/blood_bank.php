<?php
include "header.php";
$place=isset($_POST["place"])?$_POST["place"]:"";
?>

<div class="well well-sm text-center">
<span class="badge" style="font-size:20px; margin-bottom:10px">Blood Bank List</span> 
<form class="form-inline" action="blood_bank.php" method="post">
	<div class="form-group">
	<label for="plField">&nbsp;Place</label>
	<input type="text" class="form-control" id="plField" name="place" value="<?php echo $place; ?>" placeholder="Any Location or Taluka" />
	</div>

<button type="submit" class="btn btn-primary">Search</button>
</form>

</div>

<?php
include "db_conf.php";

$query="select * from blood_bank where location like '%$place%' or taluka like '%$place%'";

$result= mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."</h3>");
echo "<div class='table-responsive'>";
echo "<table class='table table-hover table-bordered table-striped'>";
echo "<tr><th>SrNo</th><th>Bank Name</th><th>Contact</th><th>Location</th><th>Taluka</th><th>Address</th></tr>";

$srno=0;

while($row=mysqli_fetch_array($result))
{
	$srno++;
	$cid=$row["bid"];
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row["bank_nm"]."</td>";
	echo "<td>".$row["con_info"]."</td>";
	echo "<td>".$row["location"]."</td>";
	echo "<td>".$row["taluka"]."</td>";
	echo "<td>".$row["address"]."</td>";
	
	echo "</tr>";
}


echo "</table>";
echo "</div>";

include "footer.php";
?>