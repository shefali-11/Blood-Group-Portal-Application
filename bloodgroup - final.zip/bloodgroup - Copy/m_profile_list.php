<?php
include "header.php";
?>
<div class=''well well-sm text-center">
<span class="badge"  style="font-size:20px; align=text-center; margin-bottom:10px">Member List</span> 
</div>
<?php
include "db_conf.php";

$query="select * from profile";

$result= mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."</h3>");
echo "<div class='table-responsive'>";
echo "<table class='table table-hover table-bordered table-striped'>";
echo "<tr><th>SrNo</th><th>Full Name</th><th>Taluka</th><th>Location</th><th>Blood Group</th><th>Contact Info</th><th>Address</th><th>Age</th><th>Gender</th><th>Photo</th></tr>";

$srno=0;

while($row=mysqli_fetch_array($result))
{
	$srno++;
	$un=$row["uname"];
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row["fullname"]."</td>";
	echo "<td>".$row["taluka"]."</td>";
	echo "<td>".$row["location"]."</td>";
	echo "<td>".$row["bgroup"]."</td>";
	echo "<td>".$row["con_info"]."</td>";
	echo "<td>".$row["address"]."</td>";
	echo "<td>".$row["age"]."</td>";
	echo "<td>".$row["gender"]."</td>";
              echo "<td><a href='images/$un.png'>View</a></td>";
	echo "</tr>";
}


echo "</table>";
echo "</div>";

include "footer.php";
?>