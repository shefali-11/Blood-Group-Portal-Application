<?php
include "header.php";

?>


<div class="well well-sm text-center">
<span class="badge" style="font-size:20px; margin-bottom:10px">Blood Requests</span> 
</div>

<?php
include "db_conf.php";

$query="select * from request  order by rid desc"; 

$result= mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."</h3>");

echo "<div class='table-responsive'>";
echo "<table class='table table-hover table-bordered table-striped'>";
echo "<tr><th>SrNo</th><th>Blood Group</th><th>For Date</th><th>Contact Person</th><th>Location</th><th>Contact Info</th><th>Action</th></tr>";

$srno=0;

while($row=mysqli_fetch_array($result))
{
	$srno++;
	$rid=$row["rid"];
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row["bgroup"]."</td>";
	echo "<td>".$row["bg_dt"]."</td>";
	echo "<td>".$row["bg_person"]."</td>";
	echo "<td>".$row["bg_loc"]."</td>";
	echo "<td>".$row["bg_con"]."</td>";
	echo "<td><a href='a_del_request.php?rid=$rid' class='btn btn-danger btn-sm'>Delete</a></td>";
              echo "</tr>";
}


echo "</table>";
echo "</div>";


include "footer.php";
?>