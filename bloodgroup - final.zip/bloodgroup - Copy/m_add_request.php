<?php
include "header.php";
?>

<div class="panel panel-danger" style="max-width:300px;margin:auto;margin-top:5px">
		<div class="panel-heading text-center">
		New Blood Request
		</div>

		<div class="panel-body">
<form class="form" action="act_new_blood_request.php" method="post">



<div class="form-group">
	<label for="bgdtField">Blood Date</label>
	<input type="date" required class="form-control" id="bgdtField" name="bg_dt" placeholder="Blood Date" />
</div>


<div class="form-group">
<label for="bgField">Blood Group Required</label>
	<select class="form-control" name="bgroup" id="bgField">
	<option>O +ve</option>
              <option>A +ve</option>
              <option>B +ve</option>
              <option>AB +ve</option>
              <option>O -ve</option>
              <option>A -ve</option>
              <option>B -ve</option>
              <option>AB -ve</option>
	</select>
</div>

<div class="form-group">
	<label for="bgField">For Person</label>
	<input type="text" required class="form-control" id="bgField" name="bg_person" placeholder="Person Name" />
</div>
<div class="form-group">
	<label for="bpField">Contact Info</label>
	<input type="text" required class="form-control" id="bpField" name="bg_con" placeholder="Contact Info" />
</div>

<div class="form-group">
	<label for="locField">Location</label>
	<input type="text" required class="form-control" id="locField" name="bg_loc" placeholder="Location" />
</div>


<input type="submit" class="btn btn-primary btn-sm btn-block" value="Add Blood Request" />
</form>
		
		</div>

		<div class="panel-footer text-center">
			
			<a href="member.php" class="btn btn-warning btn-sm">Cancel</a>
		</div>
	</div>
<?php
include "footer.php";
?>