<?php
if(!isset($_SESSION))
	session_start();

// visible to all pages
$log_user=isset($_SESSION["user"])?$_SESSION["user"]:"";
$log_role=isset($_SESSION["role"])?$_SESSION["role"]:"";

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Blood Finder Web Application</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body style='background: white'>
<div class="container">
<div class="navbar navbar-inverse">
	<div class="container-fluid">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar-content">
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		</button>

	<a class="navbar-brand" href="about.php" style='color:red'>Blood Finder</a>
	</div>
		<div class="collapse navbar-collapse" id="mynavbar-content">
			<ul class="nav navbar-nav">
				<li><a  href='index.php'>Home</a></li>
				<li><a  href='request.php'>Request</a></li>
				<li><a  href='blood_bank.php'>BloodBank</a></li>
				<li><a  href='blood_camp.php'>BloodCamp</a></li>
				<?php
				if(!empty($log_user))
				{
					$page=strtolower($log_role);
					echo "<li class='active'><a href='$page.php'>$log_role Panel</a></li>";
				}
				?>
				
			</ul>	

			<ul class="nav navbar-nav navbar-right">
				
<?php
if(empty($log_user))
{
	echo "<li><a href='register.php' style='color:aqua'>Register</a></li>";
	echo "<li><a href='login.php' style='color:aqua'>Login</a></li>";
}
else
{
	echo "<li><a href='logout.php' style='color:red'>$log_role  $log_user Logout</a></li>";
}
?>



  	      		</ul>
		</div>

	</div>
</div>
