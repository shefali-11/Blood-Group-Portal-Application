<?php
include "header.php";

$rid=$_GET["rid"];

	include "db_conf.php";

	$query="delete from request where rid='$rid'";

	mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."<a href='m_request.php'>Try Again</a></h3>");

	if(mysqli_affected_rows($con) > 0)
	{
		echo "<div class='alert alert-success text-center' style='margin-top:15px'><h3>SUCCESS: Blood Request Deleted</h3>";
		echo "<p><a href='m_request.php'>Back To List</a></p></div>";
	}
	else
	{
		echo "<div class='alert alert-danger text-center'  style='margin-top:15px'><h3>Oops! Nothing To Delete. <a href='m_request.php'>Back to List</a></h3></div>";
	}

include "footer.php";
?>