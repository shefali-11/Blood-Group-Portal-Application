<?php
include "header.php";
$un=$_GET["un"];
include "db_conf.php";

$query="select * from profile where uname='$un'";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
              $bg=$row["bgroup"];
	$fn=$row["fullname"];
	$loc=$row["location"];
	$tk=$row["taluka"];
	$adr=$row["address"];
	$ci=$row["con_info"];

}
else
{
	$bg="";
	$fn="";
	$loc="";
	$tk="";
	$adr="";
	$ci="";
}
?>
<div class="table-responsive" style="max-width:350px; margin:auto">
<table class="table table-bordered ">
<tr bgcolor='khaki'><th colspan='2' >Personal Information</th></tr>
<tr><td colspan='2' align='center' valign='middle'><?php echo "<img src='images/$un.png' width='100px' />" ?></td></tr>
<tr bgcolor='pink'><td width="50%">Blood Group</td><td width="50%"><?php echo $bg; ?></td></tr>
<tr><td width="50%">Name</td><td width="50%"><?php echo $fn; ?></td></tr>
<tr><td width="50%">Location</td><td width="50%"><?php echo $loc; ?></td></tr>
<tr><td width="50%">Taluka</td><td width="50%"><?php echo $tk; ?></td></tr>
<tr><td width="50%">Address</td><td width="50%"><?php echo $adr; ?></td></tr>
<tr><td width="50%">Contact Info</td><td width="50%"><?php echo $ci; ?></td></tr>
<tr bgcolor='aliceblue'><td colspan='2' align='center'><a href="index.php" class="btn btn-primary btn-sm ">Back</a></td></tr>
</table>
</div>

<?php
include "footer.php";
?>