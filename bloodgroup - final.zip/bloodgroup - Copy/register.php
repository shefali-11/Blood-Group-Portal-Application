<?php
include "header.php";
?>

<div class="panel panel-primary" style="max-width:300px;margin:auto;margin-top:15px">
		<div class="panel-heading text-center">
		 Registration	
		</div>

		<div class="panel-body">
<form class="form" action="act_register.php" method="post">


<div class="form-group">
	<label for="nameField"> UserName</label>
	<input type="text" required class="form-control" id="nameField" name="uname" placeholder=" User Name" />
</div>
<div class="form-group">
	<label for="nameField">New Password</label>
	<input type="password" required class="form-control" id="nameField" name="npwd" placeholder="New Password" />
</div>
<div class="form-group">
	<label for="nameField">Confirm Password</label>
	<input type="password" required class="form-control" id="nameField" name="cpwd" placeholder="Confirm Password" />
</div>

<input type="submit" class="btn btn-success btn-sm btn-block" value="Register " />
</form>
		
		</div>

		<div class="panel-footer text-center">
			
			<a href="index.php" class="btn btn-warning btn-sm">Cancel</a>
		</div>
	</div>
<?php
include "footer.php";
?>