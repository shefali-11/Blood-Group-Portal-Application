<?php
include "header.php";
$bgroup=isset($_POST["bgroup"])?$_POST["bgroup"]:"";
$place=isset($_POST["place"])?$_POST["place"]:"";
?>


<div class="well well-sm text-center">
<span class="badge" style="font-size:20px; margin-bottom:10px">Latest Blood Requirements</span> 
<form class="form-inline" action="request.php" method="post">

<div class="form-group">
<label for="bgField">Blood</label>
	<select class="form-control" name="bgroup" id="bgField">
	<option value="" <?php echo ($bgroup=="")?"selected":""; ?>>Any Blood Group</option>
              <option <?php echo ($bgroup=="O +ve")?"selected":""; ?>>O +ve</option>
              <option <?php echo ($bgroup=="A +ve")?"selected":""; ?>>A +ve</option>
              <option <?php echo ($bgroup=="B +ve")?"selected":""; ?>>B +ve</option>
              <option <?php echo ($bgroup=="AB +ve")?"selected":""; ?>>AB +ve</option>
              <option <?php echo ($bgroup=="O -ve")?"selected":""; ?>>O -ve</option>
              <option <?php echo ($bgroup=="A -ve")?"selected":""; ?>>A -ve</option>
              <option <?php echo ($bgroup=="B -ve")?"selected":""; ?>>B -ve</option>
              <option <?php echo ($bgroup=="AB -ve")?"selected":""; ?>>AB -ve</option>
	</select>
	<div class="form-group">
	<label for="plField">&nbsp;Place</label>
	<input type="text" class="form-control" id="plField" name="place" value="<?php echo $place; ?>" placeholder="Any Location or Taluka" />
</div>
</div>
<button type="submit" class="btn btn-primary">Search</button>
<a href='login.php' class="btn btn-info">Add Blood Request</a>
</form>

</div>
<?php
include "db_conf.php";

$query="select * from request where bgroup like '%$bgroup%' and (bg_loc like '%$place%') order by rid desc"; 

$result= mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."</h3>");

echo "<div class='table-responsive'>";
echo "<table class='table table-hover table-bordered table-striped'>";
echo "<tr><th>SrNo</th><th>Blood Group</th><th>For Date</th><th>Contact Person</th><th>Location</th><th>Contact Info</th></tr>";

$srno=0;

while($row=mysqli_fetch_array($result))
{
	$srno++;
	$un=$row["uname"];
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row["bgroup"]."</td>";
	echo "<td>".$row["bg_dt"]."</td>";
	echo "<td>".$row["bg_person"]."</td>";
	echo "<td>".$row["bg_loc"]."</td>";
	echo "<td>".$row["bg_con"]."</td>";
	
              echo "</tr>";
}


echo "</table>";
echo "</div>";


include "footer.php";
?>