<?php
include "header.php";
$uname=$_POST["uname"];
$pwd=$_POST["pwd"];

include "db_conf.php";

$query="select * from login where uname='$uname' and pwd='$pwd'";

$result= mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."</h3>");

if($row=mysqli_fetch_array($result))
{
	echo "<div class='alert alert-success text-center' style='margin-top:15px'><h3>Welcome $uname</h3>";
	$role=$row["role"];	
	$page=strtolower($role);
	
	$_SESSION["user"]=$uname;
	$_SESSION["role"]=$role;

	echo "<p>Go To $role Panel. <a href='$page.php'>Click Here</a></p></div>";
}
else
{
	echo "<div class='alert alert-danger text-center'  style='margin-top:15px'><h3>Invalid Credentials! <a href='index.php'>Try Again</a></h3></div>";
}

include "footer.php";
?>