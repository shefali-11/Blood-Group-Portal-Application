<?php
include "header.php";
?>
<div class="panel panel-danger" style="max-width:300px;margin:auto;margin-top:15px">
		<div class="panel-heading text-center">
		Blood Finder Web App Login	
		</div>

		<div class="panel-body">
<form class="form" action="act_login.php" method="post">
<div class="form-group">
	<label for="nameField">UserName</label>
	<input type="text" required class="form-control" id="nameField" name="uname" placeholder="User Name" />
</div>
<div class="form-group">
	<label for="nameField">Password</label>
	<input type="password" required class="form-control" id="nameField" name="pwd" placeholder="Password" />
</div>
<input type="submit" class="btn btn-danger btn-sm btn-block" value="Login" />
</form>
		
		</div>

		<div class="panel-footer text-center">
			
			<a href="register.php" class="btn btn-success btn-sm">Register Member</a>
		</div>
	</div>
<?php
include "footer.php";
?>