<?php
include "header.php";
?>
<h3 style='color:maroon'>Member Action Panel</h3>
<div class="list-group">
	<a href="profile.php" class="list-group-item">Update Profile</a>
	<a href="m_update_photo.php" class="list-group-item">Update Photo</a>
	<a href="index.php" class="list-group-item">Search Blood </a>
	<a href="m_add_request.php" class="list-group-item">Add Request</a>
	<a href="m_request.php" class="list-group-item">My Requests</a>
	<a  href='blood_bank.php' class="list-group-item">Blood Bank List</a>
	<a  href='blood_camp.php' class="list-group-item">Blood Camp List</a>
  </div>
<?php
include "footer.php";
?>