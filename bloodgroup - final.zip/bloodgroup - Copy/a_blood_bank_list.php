<?php
include "header.php";

include "db_conf.php";

$query="select * from blood_bank";

$result= mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."</h3>");
echo "<div class='table-responsive'>";
echo "<table class='table table-hover table-bordered table-striped'>";
echo "<tr><th>SrNo</th><th>Bank Name</th><th>Contact</th><th>Location</th><th>Taluka</th><th>Address</th><th>Action</th></tr>";

$srno=0;

while($row=mysqli_fetch_array($result))
{
	$srno++;
	$cid=$row["bid"];
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row["bank_nm"]."</td>";
	echo "<td>".$row["con_info"]."</td>";
	echo "<td>".$row["location"]."</td>";
	echo "<td>".$row["taluka"]."</td>";
	echo "<td>".$row["address"]."</td>";
	echo "<td>";
	echo "&nbsp;<a href='a_edit_blood.php? class='btn btn-info btn-xs'>Edit</a>";
	echo "&nbsp;&nbsp;<a href='a_del_blood.php? class='btn btn-danger btn-xs'>Delete</a>";
	echo "</td>";
	echo "</tr>";
}


echo "</table>";
echo "</div>";

include "footer.php";
?>