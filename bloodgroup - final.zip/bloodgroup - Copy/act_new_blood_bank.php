<?php
include "header.php";
include "db_conf.php";

$bnm=$_POST["bnm"];
$ci=$_POST["ci"];
$loc=$_POST["loc"];
$tal=$_POST["tal"];
$adr=$_POST["adr"];



$query="insert into blood_bank(bank_nm,con_info,location,taluka,address) values('$bnm','$ci','$loc','$tal','$adr')";

	mysqli_query($con,$query) or die("<h3 style='color:red'>".mysqli_error($con)."<a href='new_blood_bank.php'>Try Again</a></h3>");

	if(mysqli_affected_rows($con) > 0)
	{
		
		echo "<div class='alert alert-success text-center' style='margin-top:15px'><h3>SUCCESS: New Blood Bank Added</h3>";
		echo "<p><a href='a_blood_bank.php'>Back To List</a></p></div>";
	}
	else
	{
		echo "<div class='alert alert-danger text-center'  style='margin-top:15px'><h3>ERROR: Cannot Add Crop. <a href='new_blood_bank.php'>Try Again</a></h3></div>";
	}


include "footer.php";
?>