<?php
// @ sign to hide warning
// mysql server address, user, pwd, database name
$con=@mysqli_connect("localhost","root","","bg_db");

if(!$con)
	exit("<h3 style='color:red'>Cannot Connect To Database</h3>");
?>