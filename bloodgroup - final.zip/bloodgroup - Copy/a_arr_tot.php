<table boder='1' cellpading='5'>
<?php
define("MAX_ROWS",3);	// defines constant
define("MAX_COLS",3);

// 2-dimensional array
$mtx=array(array(1,2,3,1),array(4,5,6));

echo "Second Row Third Column: ".$mtx[1][2];	

echo "<br/>Count Rows: ".count($mtx);

$mtx[]=array(7,8,9);

echo "<hr/>";

for($r=0;$r<MAX_ROWS;$r++)
{
	echo "<tr>"
	
	for($c=0;$c<MAX_COLS;$c++)
	{
		

		echo "<td align='center'>"$mtx[$r][$c]."  ""</td>";
	}
	echo "<br/>";
	"</tr>"
	
}

echo "<pre>";
print_r($mtx);
echo "</pre>";	

?>
</table>