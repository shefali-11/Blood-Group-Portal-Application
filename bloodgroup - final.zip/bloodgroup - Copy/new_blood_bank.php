<?php
include "header.php";
?>

<div class="panel panel-primary" style="max-width:300px;margin:auto;margin-top:5px">
		<div class="panel-heading text-center">
		New Blood Bank
		</div>

		<div class="panel-body">
<form class="form" action="act_new_blood_bank.php" method="post">

<div class="form-group">
	<label for="bnmField">Bank Name</label>
	<input type="text" required class="form-control" id="bnmField" name="bnm" placeholder="Bank Name" />
</div>

<div class="form-group">
	<label for="conField">Contact</label>
	<input type="text" required class="form-control" id="conField" name="ci" placeholder="Contact" />
</div>

<div class="form-group">
	<label for="locField">loaction</label>
	<input type="text" required class="form-control" id="locField" name="loc" placeholder="Location" />
</div>

<div class="form-group">
	<label for="talField">taluka</label>
	<input type="text" required class="form-control" id="talField" name="tal" placeholder="Taluka" />
</div>

<div class="form-group">
	<label for="adrField">Address</label>
	<input type="text" required class="form-control" id="adrField" name="adr" placeholder="Address" />
</div>

<input type="submit" class="btn btn-success btn-sm btn-block" value="Add Blood Bank" />
</form>
		
		</div>

		<div class="panel-footer text-center">
			
			<a href="m_blood_bank.php" class="btn btn-warning btn-sm">Cancel</a>
		</div>
	</div>
<?php
include "footer.php";
?>