<?php
include "header.php";
?>
<h3 style='color:maroon'>Admin Action Panel</h3>
<div class="list-group">
	<a href="m_profile_list.php" class="list-group-item">Member List</a>
	<a href="new_blood_bank.php" class="list-group-item">Add Blood Bank</a>
	<a href="a_blood_bank_list.php" class="list-group-item">Manage Blood Bank List</a>
	<a href="new_blood_camp.php" class="list-group-item">Add Blood Camp Info</a>
	<a href="a_blood_camp_list.php" class="list-group-item">Manage Blood Camp List</a>
	<a href="a_request_list.php" class="list-group-item">Manage Request List</a>
  </div>
<?php
include "footer.php";
?>