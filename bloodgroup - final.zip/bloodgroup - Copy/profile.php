<?php
include "header.php";
include "db_conf.php";

$query="select * from profile where uname='$log_user'";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$fn=$row["fullname"];
	$loc=$row["location"];
	$tal=$row["taluka"];
	$bg=$row["bgroup"];
	$age=$row["age"];
	$ge=$row["gender"];
	$adr=$row["address"];
	$ci=$row["con_info"];
}
else
{
	$fn="";
	$loc="";
	$adr="";
	$ci="";
	$tal="";
	$ge="";
	$age="";
	$bg="";
}
?>

<div class="panel panel-danger" style="max-width:300px;margin:auto;margin-top:15px">
		<div class="panel-heading text-center">
		Member Profile	
		</div>

		<div class="panel-body">
<form class="form" action="act_mp.php" method="post">
<div class="form-group">
	<label for="nameField">Name</label>
	<input type="text" class="form-control" id="nameField" name="fn" value="<?php echo $fn; ?>" placeholder="Name" />
</div>
<div class="form-group">
	<label for="locField">Location</label>
	<input type="text" class="form-control" id="locField" name="loc"  value="<?php echo $loc; ?>" placeholder="Location" />
</div>
<div class="form-group">
	<label for="talField">Taluka</label>
	<input type="text" class="form-control" id="talField" name="tal"  value="<?php echo $tal; ?>" placeholder="Taluka" />
</div>
<div class="form-group">
	<label for="nameField">Contact info</label>
	<input type="text" class="form-control" id="ciField" name="ci"  value="<?php echo $ci; ?>" placeholder="Mobile No. / Email" />
</div>

<div class="form-group">
<label for="bgField">Blood</label>
	<select class="form-control" name="bg" id="bgField">
              <option >O +ve</option>
              <option >A +ve</option>
              <option >B +ve</option>
              <option >AB +ve</option>
              <option >O -ve</option>
              <option >A -ve</option>
              <option >B -ve</option>
              <option >AB -ve</option>
	</select>
</div>
<div class="form-group">
	<label for="geField">Gender</label>
	<select class="form-control" name="ge" id="geField">
              <option >Male</option>
              <option >Female</option>
              <option >Other</option>
	</select>
</div>
<div class="form-group">
	<label for="ageField">Age</label>
	<input type="text" class="form-control" id="ageField" name="age"  value="<?php echo $age; ?>" placeholder="Age" />
</div>
<div class="form-group">
	<label for="adrField">Address</label>
	<input type="text" class="form-control" id="adrField" name="adr"  value="<?php echo $adr; ?>" placeholder="Address" />
</div>
<input type="submit" class="btn btn-primary btn-sm btn-block" value="Update Profile" />
</form>
		
		</div>

		<div class="panel-footer text-center">
			
			<a href="member.php" class="btn btn-warning btn-sm">Back</a>
		</div>
	</div>
<?php
include "footer.php";
?>