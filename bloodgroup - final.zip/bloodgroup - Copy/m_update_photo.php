<?php
include "header.php";
?>
<div class="panel panel-primary" style="max-width:300px;margin:auto;">
	
	<div class="panel-heading text-center">
		Update Profile 	
	</div>
	
	<div class="panel-body text-center">
	<div class="form-group">
	<?php 
		echo file_exists('images/$log_user.png');
		if(file_exists("./images/$log_user.png")==1)
			echo "<a href='#'><img src='images/$log_user.png' width='200px' /></a><br/>"; 
		else
			echo "<a href='#'><img src='images/none.png' width='200px' /></a><br/>"; 
	?>
	</div>

	<form action="act_update_photo.php" method="post" enctype="multipart/form-data">

	<div class="form-group">
	<label for="nameField" class='badge' style="background:maroon">Select  Image</label>
	<input type="file" class="form-control" id="nameField" name="fp" placeholder="Select File" />
	</div>
	</div>

	<div class="panel-footer text-center">
	<input type="submit" class="btn btn-success btn-sm btn-block" value="Upload" /><br/>
	<a class="btn btn-warning btn-sm"  href='member.php'>Back</a>
	</div>
</div>
</form>
<?php
include "footer.php"
?>
