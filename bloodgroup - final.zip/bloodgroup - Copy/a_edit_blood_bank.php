<?php
include "header.php";
include "db_conf.php";

$bid=$_GET["bid"];

$query="select * from blood_bank where bid='$bid'";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$bnm=$row["bank_nm"];
	$con=$row["con_info"];
	$loc=$row["location"];
	$tal=$row["taluka"];
	$adr=$row["address"];
}
else
{
	$bnm="";
	$con="";
	$loc="";
	$tal="";
	$adr="";
}
?>

<div class="panel panel-danger" style="max-width:300px;margin:auto;margin-top:5px">
		<div class="panel-heading text-center">
		Edit Blood Bank Info
		</div>

		<div class="panel-body">
<form class="form" action="act_edit_blood_bank.php" method="post">

<input type="hidden" name="bid" value="<?php echo $bid; ?>" />

<div class="form-group">
	<label for="bnmField">Bank Name</label>
	<input type="text" required class="form-control" id="bnmField" name="bnm" value="<?php echo $bnm; ?>" placeholder="Bank Name" />
</div>

<div class="form-group">
	<label for="conField">Contact</label>
	<input type="text" required class="form-control" id="conField" name="con" value="<?php echo $con; ?>" placeholder="Contact Info" />
</div>

<div class="form-group">
	<label for="locField">Location</label>
	<input type="text" required class="form-control" id="locField" name="loc" value="<?php echo $loc; ?>"  placeholder="Location" />
</div>

<div class="form-group">
	<label for="talField">Taluka</label>
	<input type="text" required class="form-control" id="talField" name="tal" value="<?php echo $tal; ?>" placeholder="Taluka" />
</div>

<div class="form-group">
	<label for="adrField">address</label>
	<input type="text" required class="form-control" id="adrField" name="adr" value="<?php echo $adr; ?>" placeholder="Address" />
</div>

<input type="submit" class="btn btn-primary btn-sm btn-block" value="Update Blood Bank" />
</form>
		
		</div>

		<div class="panel-footer text-center">
			
			<a href="a_blood_bank_list.php" class="btn btn-warning btn-sm">Cancel</a>
		</div>
	</div>
<?php
include "footer.php";
?>