<?php
include "header.php";

$type=$_FILES["fp"]["type"];
$tmp_name=$_FILES["fp"]["tmp_name"];
$error=$_FILES["fp"]["error"];
$size=$_FILES["fp"]["size"];
echo "<center>";
if($error==4)
	echo "<h3 style='color:red'>Error: File Not Selected</h3>";
else
{
	if($type=='image/jpeg' || $type=='image/png')
	{
		$to_loc="./images/$log_user.png";

		move_uploaded_file($tmp_name, $to_loc);

		echo "<h3 style='color:green' >Success:  Profile Uploaded</h3>";

		echo "<a href='$to_loc'><img src='$to_loc' width='200px' /></a>";
	}
	else
	           echo "<h3 style='color:red'>Error: Invalid Picture File. Allowed .jpg or .png Only</h3>";
}

echo "<p><a href='member.php'>Back To Panel</a></p>";
echo "</center>";
include "footer.php";
?>
