<?php
include "header.php";

// unset all session variables
session_destroy();

$log_user="";
$log_role="";

// auto-redirect
header("location: login.php");


include "footer.php";
?>
